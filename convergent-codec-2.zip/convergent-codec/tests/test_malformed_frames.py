import pytest
from convergent_codec import encode, CodecFormatError
from convergent_codec.frames import deserialize, serialize_periodic_sparse, RESIDUAL_NONE
from convergent_codec.generators import generate_periodic
from convergent_codec.canonical import pack_mask


def test_truncated_rejected():
    c = encode([1, 2, 3])
    with pytest.raises(CodecFormatError):
        deserialize(c.frame[:-5])


def test_trailing_bytes_rejected():
    c = encode([1, 2, 3])
    with pytest.raises(CodecFormatError):
        deserialize(c.frame + b"\x00")


def test_wrong_digest_rejected():
    c = encode([10, 20, 30])
    bad = bytearray(c.frame)
    bad[-1] ^= 0xFF
    with pytest.raises(CodecFormatError):
        deserialize(bytes(bad))


def test_unknown_version_rejected():
    c = encode([1])
    bad = bytearray(c.frame)
    bad[0] = 99
    with pytest.raises(CodecFormatError):
        deserialize(bytes(bad))


def test_out_of_range_int32_rejected():
    with pytest.raises(CodecFormatError):
        encode([2**31])
    with pytest.raises(CodecFormatError):
        encode([-(2**31) - 1])


def test_non_canonical_mask_padding_rejected():
    # Build a valid periodic frame for 9 samples, then corrupt padding bits
    vals = generate_periodic(9, 4, 5, 0, 1)
    mask = [False] * 9
    mask[0] = True
    frame = serialize_periodic_sparse(
        vals, 4, 5, 0, 1, mask, [vals[0] - 5], [0]*9, residual_mode=RESIDUAL_NONE
    )
    # Corrupt the high bits of the last mask byte
    # mask is after: version(1) family(1) sample_count varint(1 for 9) period varint amp zig phase varint gen residual_mode
    # Find mask location roughly and flip high bit
    bad = bytearray(frame)
    # Safer: locate the mask by reconstructing offsets
    # version + family = 2
    # sample_count=9 → 1 byte varint
    # period=4 → 1
    # amplitude=5 → 1 zig
    # phase=0 → 1
    # gen + residual_mode = 2
    # mask starts at offset 2+1+1+1+1+2 = 8, length 2 bytes for 9 samples
    mask_start = 8
    # set high bits of second mask byte
    bad[mask_start + 1] |= 0xFE  # set all but lowest
    with pytest.raises(CodecFormatError, match="non-canonical mask padding"):
        deserialize(bytes(bad))
